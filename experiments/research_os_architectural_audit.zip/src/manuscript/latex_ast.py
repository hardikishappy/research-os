"""Robust Structured LaTeX Abstract Syntax Tree (AST) & Escaping Pipeline.

Enforces Directive 4:
- Eliminates fragile string-concatenation LaTeX generation.
- Full escaping of TeX special characters (_, %, <=, >=, &, #, $, {, }, ^, ~).
- Absolute/bundle-relative path resolution for figures independent of shell CWD.
"""

from __future__ import annotations

import os
import re
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Optional, Sequence, Union


def escape_latex(text: str) -> str:
    """Safely escape all LaTeX control characters and mathematical comparison operators.
    
    Order of operations is critical:
    1. Escape backslashes, ampersands, percent signs, dollar signs, hashes, underscores, braces, tildes, carets.
    2. Replace mathematical comparison operators (<=, >=, !=, ==, standalone <, >) with clean math mode symbols.
    """
    if not text:
        return ""

    s = str(text)

    # 1. Backslashes and control symbols first (so subsequent math delimiters are not escaped)
    replacements = [
        ("&", "\\&"),
        ("%", "\\%"),
        ("$", "\\$"),
        ("#", "\\#"),
        ("_", "\\_"),
        ("{", "\\{"),
        ("}", "\\}"),
        ("~", "\\textasciitilde{}"),
        ("^", "\\textasciicircum{}"),
    ]

    for char, escaped in replacements:
        s = s.replace(char, escaped)

    # 2. Operators safely introducing math-mode delimiters
    s = s.replace("<=", " $\\le$ ")
    s = s.replace(">=", " $\\ge$ ")
    s = s.replace("!=", " $\\ne$ ")
    s = s.replace("==", " $=$ ")

    # Standalone < and > (not part of $\le$ or tags)
    s = re.sub(r"(?<!\\le\s)(?<!\\ge\s)<(?!=)", " $<$ ", s)
    s = re.sub(r"(?<!\\le\s)(?<!\\ge\s)>(?!=)", " $>$ ", s)

    # Clean up duplicate whitespace introduced by operator spacing
    s = re.sub(r"[ \t]+", " ", s)
    return s.strip()


def resolve_figure_path(figure_path: Union[str, Path], manuscript_dir: Union[str, Path]) -> str:
    """Resolve a figure file path to a clean, portable forward-slash relative or absolute path.
    
    Guarantees compilation does not depend on the shell's current working directory.
    """
    m_dir = Path(manuscript_dir).resolve()
    fig = Path(figure_path)

    # If already relative to manuscript_dir
    if not fig.is_absolute():
        resolved_fig = (m_dir / fig).resolve()
    else:
        resolved_fig = fig.resolve()

    try:
        rel = resolved_fig.relative_to(m_dir)
        # Always use forward slashes for TeX graphics compatibility
        return rel.as_posix()
    except ValueError:
        # Fall back to normalized absolute forward-slash path
        return resolved_fig.as_posix()


class LatexNode(ABC):
    """Abstract base class for all LaTeX AST elements."""

    @abstractmethod
    def render(self) -> str:
        """Render the node to valid LaTeX code."""
        pass


class LatexText(LatexNode):
    """Text node with automatic escaping of LaTeX control characters."""

    def __init__(self, text: str, raw: bool = False) -> None:
        self.text = text
        self.raw = raw

    def render(self) -> str:
        return self.text if self.raw else escape_latex(self.text)


class LatexRaw(LatexNode):
    """Verbatim LaTeX snippet (e.g. mathematical equation or custom package command)."""

    def __init__(self, snippet: str) -> None:
        self.snippet = snippet

    def render(self) -> str:
        return self.snippet


class LatexCommand(LatexNode):
    """A standard LaTeX command (e.g. \\section{...}, \\caption{...})."""

    def __init__(
        self,
        command: str,
        argument: Union[str, LatexNode],
        options: Optional[str] = None,
        escape_arg: bool = True,
    ) -> None:
        self.command = command
        self.argument = argument
        self.options = options
        self.escape_arg = escape_arg

    def render(self) -> str:
        if isinstance(self.argument, LatexNode):
            arg_str = self.argument.render()
        else:
            arg_str = escape_latex(self.argument) if self.escape_arg else str(self.argument)

        opts_str = f"[{self.options}]" if self.options else ""
        return f"\\{self.command}{opts_str}{{{arg_str}}}"


class LatexEnvironment(LatexNode):
    """A LaTeX block environment (\\begin{name}...\\end{name})."""

    def __init__(
        self,
        name: str,
        options: Optional[str] = None,
        children: Optional[list[LatexNode]] = None,
    ) -> None:
        self.name = name
        self.options = options
        self.children = children or []

    def add(self, child: LatexNode) -> LatexEnvironment:
        self.children.append(child)
        return self

    def render(self) -> str:
        opts_str = f"[{self.options}]" if self.options else ""
        body = "\n".join(c.render() for c in self.children)
        return f"\\begin{{{self.name}}}{opts_str}\n{body}\n\\end{{{self.name}}}"


class LatexTable(LatexNode):
    """Professional academic table rendered using booktabs with cell-level auto-escaping."""

    def __init__(
        self,
        headers: Sequence[Union[str, LatexNode]],
        rows: Sequence[Sequence[Union[str, LatexNode]]],
        caption: str = "",
        label: str = "",
        alignment: Optional[str] = None,
        pos: str = "h",
        footnote: Optional[str] = None,
    ) -> None:
        self.headers = headers
        self.rows = rows
        self.caption = caption
        self.label = label
        self.pos = pos
        self.alignment = alignment or ("l" + "c" * (len(headers) - 1))
        self.footnote = footnote

    def _render_cell(self, cell: Union[str, LatexNode]) -> str:
        if isinstance(cell, LatexNode):
            return cell.render()
        return escape_latex(str(cell))

    def render(self) -> str:
        lines: list[str] = []
        lines.append(f"\\begin{{table}}[{self.pos}]")
        lines.append("\\centering")
        if self.caption:
            lines.append(f"\\caption{{{escape_latex(self.caption)}}}")
        if self.label:
            lines.append(f"\\label{{{self.label}}}")

        lines.append(f"\\begin{{tabular}}{{{self.alignment}}}")
        lines.append("\\toprule")

        # Escaped headers or rendered nodes
        escaped_headers = [self._render_cell(h) for h in self.headers]
        lines.append(" & ".join(escaped_headers) + " \\\\")
        lines.append("\\midrule")

        # Escaped row cells or rendered nodes
        for row in self.rows:
            escaped_row = [self._render_cell(cell) for cell in row]
            lines.append(" & ".join(escaped_row) + " \\\\")

        lines.append("\\bottomrule")
        lines.append("\\end{tabular}")
        if self.footnote:
            lines.append(f"\\vspace{{2pt}}\n\\par\\footnotesize{{{escape_latex(self.footnote)}}}")
        lines.append("\\end{table}")
        return "\n".join(lines)


class LatexFigure(LatexNode):
    """Structured figure node resolving assets relative to manuscript directory."""

    def __init__(
        self,
        figure_path: Union[str, Path],
        manuscript_dir: Union[str, Path],
        caption: str = "",
        label: str = "",
        width: str = "\\columnwidth",
        pos: str = "h",
    ) -> None:
        self.resolved_path = resolve_figure_path(figure_path, manuscript_dir)
        self.caption = caption
        self.label = label
        self.width = width
        self.pos = pos

    def render(self) -> str:
        lines: list[str] = []
        lines.append(f"\\begin{{figure}}[{self.pos}]")
        lines.append("\\centering")
        lines.append(f"\\includegraphics[width={self.width}]{{{self.resolved_path}}}")
        if self.caption:
            lines.append(f"\\caption{{{escape_latex(self.caption)}}}")
        if self.label:
            lines.append(f"\\label{{{self.label}}}")
        lines.append("\\end{figure}")
        return "\n".join(lines)


class LatexDocument(LatexNode):
    """Complete publication-ready LaTeX document compiler."""

    def __init__(
        self,
        documentclass: str = "IEEEtran",
        options: str = "10pt,journal,compsoc",
        packages: Optional[list[str]] = None,
    ) -> None:
        self.documentclass = documentclass
        self.options = options
        self.packages = packages or [
            "amsmath,amssymb,amsfonts",
            "booktabs",
            "graphicx",
            "hyperref",
            "cite",
        ]
        self.body_nodes: list[LatexNode] = []

    def add(self, node: LatexNode) -> LatexDocument:
        self.body_nodes.append(node)
        return self

    def render(self) -> str:
        lines: list[str] = []
        opts = f"[{self.options}]" if self.options else ""
        lines.append(f"\\documentclass{opts}{{{self.documentclass}}}")
        for pkg in self.packages:
            lines.append(f"\\usepackage{{{pkg}}}")
        lines.append("\\begin{document}\n")

        for node in self.body_nodes:
            lines.append(node.render())
            lines.append("")

        lines.append("\\end{document}\n")
        return "\n".join(lines)
