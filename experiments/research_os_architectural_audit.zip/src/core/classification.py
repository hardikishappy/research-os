"""Experiment classification schemas for Research OS (Directive 3).

Enforces:
- Explicit ontological separation between real-world empirical data, in-silico simulations,
  synthetic benchmarks, and literature reproductions.
- Scientific integrity constraints derived from experimental modality.
"""

from __future__ import annotations

from enum import Enum


class ExperimentClass(str, Enum):
    """Rigorous epistemic classification of research experiment execution."""

    EMPIRICAL = "EMPIRICAL"                         # Real-world physical or observational measurements
    SIMULATION = "SIMULATION"                       # Computational modeling or in-silico physics
    SYNTHETIC_BENCHMARK = "SYNTHETIC_BENCHMARK"     # Programmatic or algorithmic synthetic workloads
    REPRODUCTION = "REPRODUCTION"                   # Exact recreation of previously published protocols
