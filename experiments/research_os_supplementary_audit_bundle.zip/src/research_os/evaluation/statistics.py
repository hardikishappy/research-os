"""Strictly Typed Statistical Inference Engine for Research OS (Directive 2).

Enforces:
- Separation of descriptive metric aggregation from formal inferential statistics.
- Strict Golden Rule of Statistics:
    If variance == 0.0 or sample_size < power_threshold or p_value is None:
        significance_claim_allowed = False.
- Transparent hypothesis testing (Student's t-test, confidence intervals, degrees of freedom).
- Independent observational units strictly differentiated from seeds or loops.
"""

from __future__ import annotations

import math
from typing import Optional, Sequence

from research_os.schemas.evaluation import StatisticalAnalysisResult


def _log_gamma(x: float) -> float:
    """Natural logarithm of the Gamma function via Lanczos approximation."""
    return math.lgamma(x)


def _betainc(a: float, b: float, x: float) -> float:
    """Regularized incomplete beta function I_x(a, b) via continued fraction (Lentz's method)."""
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0

    # Symmetry transformation for rapid convergence
    if x > (a + 1.0) / (a + b + 2.0):
        return 1.0 - _betainc(b, a, 1.0 - x)

    lbeta = _log_gamma(a) + _log_gamma(b) - _log_gamma(a + b)
    front = math.exp(a * math.log(x) + b * math.log(1.0 - x) - lbeta) / a

    # Continued fraction
    f = 1.0
    c = 1.0
    d = 0.0
    tiny = 1e-30

    for m in range(1, 140):
        # Even step
        m2 = 2 * m
        d_even = (m * (b - m) * x) / ((a + m2 - 1.0) * (a + m2))
        d = 1.0 + d_even * d
        if abs(d) < tiny:
            d = tiny
        c = 1.0 + d_even / c
        if abs(c) < tiny:
            c = tiny
        d = 1.0 / d
        f *= c * d

        # Odd step
        d_odd = -((a + m) * (a + b + m) * x) / ((a + m2) * (a + m2 + 1.0))
        d = 1.0 + d_odd * d
        if abs(d) < tiny:
            d = tiny
        c = 1.0 + d_odd / c
        if abs(c) < tiny:
            c = tiny
        d = 1.0 / d
        del_val = c * d
        f *= del_val

        if abs(del_val - 1.0) < 1e-10:
            break

    return front * (f - 1.0)


def student_t_p_value(t_stat: float, df: int) -> float:
    """Calculate two-tailed p-value for Student's t distribution."""
    if df <= 0:
        return 1.0
    if math.isnan(t_stat) or math.isinf(t_stat):
        return 1.0

    t_abs = abs(t_stat)
    if t_abs == 0.0:
        return 1.0

    # For large df, use normal approximation
    if df > 300:
        # 2 * (1 - Phi(|t|)) = erfc(|t| / sqrt(2))
        return math.erfc(t_abs / math.sqrt(2.0))

    # Two-tailed p-value = I_{df / (df + t^2)}(df/2, 1/2)
    x = df / (df + t_abs * t_abs)
    try:
        p_val = _betainc(df / 2.0, 0.5, x)
        return max(0.0, min(1.0, float(p_val)))
    except Exception:
        # Fallback to normal
        return math.erfc(t_abs / math.sqrt(2.0))


def compute_statistical_inference(
    sample_values: Sequence[float],
    target_threshold: Optional[float] = None,
    operator: str = ">=",
    metric_name: str = "metric",
    power_threshold: int = 2,
    alpha: float = 0.05,
) -> StatisticalAnalysisResult:
    """Compute rigorous statistical inference for sample metrics.

    Enforces Directive 2:
    - If variance == 0.0: blocks significance claims (SD == 0.0000 cannot claim p < 0.05).
    - If sample_size < power_threshold: blocks significance claims.
    - If p_value is None or >= alpha: significance_claim_allowed = False.
    """
    n = len(sample_values)
    reasons_blocked: list[str] = []

    if n == 0:
        return StatisticalAnalysisResult(
            metric_name=metric_name,
            sample_size=0,
            mean=0.0,
            variance=0.0,
            standard_deviation=0.0,
            standard_error=0.0,
            degrees_of_freedom=0,
            test_statistic=None,
            p_value=None,
            confidence_interval=None,
            assumptions_met=False,
            significance_claim_allowed=False,
            reasons_significance_blocked=["Empty sample (N=0)"],
        )

    mean = sum(sample_values) / n

    if n < 2:
        variance = 0.0
        sd = 0.0
        se = 0.0
        df = 0
    else:
        variance = sum((x - mean) ** 2 for x in sample_values) / (n - 1)
        sd = math.sqrt(variance)
        se = sd / math.sqrt(n)
        df = n - 1

    # Golden Rule Checks:
    # 1. Zero Variance
    if n > 1 and variance == 0.0:
        reasons_blocked.append("Zero variance across observational units (SD == 0.0000); identical outputs cannot establish statistical significance")

    # 2. Power Threshold
    if n < power_threshold:
        reasons_blocked.append(f"Sample size N={n} is below statistical power threshold (N >= {power_threshold} required)")

    # 3. Test Statistic and p-value computation
    t_stat: Optional[float] = None
    p_val: Optional[float] = None
    ci: Optional[tuple[float, float]] = None

    if se > 0.0 and df > 0:
        # One-sample t-test comparing sample mean to target_threshold
        comp_thresh = target_threshold if target_threshold is not None else 0.0
        t_stat = (mean - comp_thresh) / se
        p_val = student_t_p_value(t_stat, df)

        # 95% Confidence Interval approximation (t_crit ~ 2.0 to 4.3 for small df)
        # Approximate t_crit via binary search or standard constants
        t_crit = 1.96 if df > 30 else (2.776 if df == 4 else (3.182 if df == 3 else (4.303 if df == 2 else 12.706)))
        ci = (round(mean - t_crit * se, 4), round(mean + t_crit * se, 4))
    else:
        # Zero variance or single sample: p-value is uninformative
        t_stat = None
        p_val = None
        ci = (mean, mean)

    if p_val is None:
        reasons_blocked.append("p-value estimate is uninformative / undefined")
    elif p_val >= alpha:
        reasons_blocked.append(f"Observed p-value ({p_val:.4f}) does not meet significance threshold (alpha = {alpha})")

    # Directional / Condition consistency
    condition_passed = False
    if target_threshold is None:
        condition_passed = True
    elif operator == ">=":
        condition_passed = mean >= target_threshold
    elif operator == "<=":
        condition_passed = mean <= target_threshold
    elif operator == ">":
        condition_passed = mean > target_threshold
    elif operator == "<":
        condition_passed = mean < target_threshold
    elif operator == "==":
        condition_passed = abs(mean - target_threshold) <= 1e-4

    if not condition_passed:
        reasons_blocked.append(f"Sample mean ({mean:.4f}) does not satisfy expected condition ({operator} {target_threshold})")

    assumptions_met = (variance > 0.0) and (n >= 2)
    significance_allowed = (len(reasons_blocked) == 0) and condition_passed and (p_val is not None and p_val < alpha)

    return StatisticalAnalysisResult(
        metric_name=metric_name,
        sample_size=n,
        mean=round(mean, 6),
        variance=round(variance, 6),
        standard_deviation=round(sd, 6),
        standard_error=round(se, 6),
        degrees_of_freedom=df,
        test_statistic=round(t_stat, 4) if t_stat is not None else None,
        p_value=round(p_val, 6) if p_val is not None else None,
        confidence_interval=ci,
        assumptions_met=assumptions_met,
        significance_claim_allowed=significance_allowed,
        reasons_significance_blocked=reasons_blocked,
    )
