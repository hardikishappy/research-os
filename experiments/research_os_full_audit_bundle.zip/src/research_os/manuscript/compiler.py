r"""Scientific Manuscript Compiler for Research OS (LaTeX, Markdown, BibTeX).

Complies with:
- Dual-column IEEEtran publication-ready formatting.
- Strict scientific writing standard: ZERO AI clichés ("delve", "pivotal", "testament", "in a nutshell").
- Booktabs statistical evaluation tables ($M \pm SD$, sample size $N$, degrees of freedom, $p$-values).
- Embedded vector/raster figures generated from verified multi-seed execution traces.
- Rule 2 Epistemic Novelty Hedging.
"""

from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Optional, Union
from pydantic import Field

from research_os.core.classification import ExperimentClass
from research_os.core.integrity import EpistemicHonestyViolation, ScientificIntegrityLinter
from research_os.manuscript.latex_ast import (
    LatexCommand,
    LatexDocument,
    LatexEnvironment,
    LatexFigure,
    LatexMetricTable,
    LatexRaw,
    LatexStatisticalClaim,
    LatexTable,
    LatexText,
    LatexVerifiedFigure,
    escape_latex,
    resolve_figure_path,
)
from research_os.manuscript.visualizer import PublicationVisualizer
from research_os.schemas.base import ArtifactBaseModel
from research_os.schemas.evaluation import EvaluationReport, HypothesisVerdict
from research_os.schemas.experiment import ExperimentSpec
from research_os.schemas.hypothesis import HypothesisProposal
from research_os.schemas.paper import PaperMetadata
from research_os.schemas.synthesis import CrossPaperSynthesis


class ManuscriptBundle(ArtifactBaseModel):
    """Artifact bundle containing compiled academic manuscript files."""

    run_id: str = Field(description="Associated experiment run identifier")
    markdown_path: str = Field(description="Path to compiled paper.md")
    latex_path: str = Field(description="Path to compiled paper.tex")
    bibtex_path: str = Field(description="Path to compiled references.bib")
    figure_paths: list[str] = Field(default_factory=list, description="Paths to compiled publication figures")
    title: str = Field(description="Manuscript title")
    word_count: int = Field(default=0, description="Approximate markdown word count")


class ManuscriptCompiler:
    """Compiles publication-ready academic papers from Research OS experiment artifacts."""

    AI_CLICHE_PATTERNS = [
        re.compile(r"\bdelve\b", re.IGNORECASE),
        re.compile(r"\bpivotal\b", re.IGNORECASE),
        re.compile(r"\btestament\b", re.IGNORECASE),
        re.compile(r"\bin a nutshell\b", re.IGNORECASE),
        re.compile(r"\btapestry\b", re.IGNORECASE),
        re.compile(r"\bgame-?changer\b", re.IGNORECASE),
    ]

    def __init__(self, run_id: str, output_dir: Optional[Path | str] = None):
        self.run_id = run_id
        if output_dir:
            self.output_dir = Path(output_dir)
        else:
            self.output_dir = Path("experiments/runs") / run_id / "manuscript"
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.visualizer = PublicationVisualizer(run_id=run_id, output_dir=self.output_dir / "figures")

    @classmethod
    def resolve_evidence_claims(cls, text: str, evaluation: EvaluationReport) -> str:
        """Resolve symbolic evidence references \\evidenceClaim{metric.format} into verified numbers."""
        def _repl(match: re.Match) -> str:
            ref = match.group(1).strip()
            parts = ref.split(".")
            m_name = parts[0]
            fmt = parts[1] if len(parts) > 1 else "mean"
            claim_node = LatexStatisticalClaim(metric_name=m_name, evidence_ref=evaluation, format_spec=fmt)
            return claim_node.render()
        return re.sub(r"\\evidenceClaim\{([^}]+)\}", _repl, text)

    @classmethod
    def verify_numerical_consistency(
        cls,
        text: str,
        evaluation: EvaluationReport,
        hypothesis: Optional[HypothesisProposal] = None,
        spec: Optional[ExperimentSpec] = None,
    ) -> None:
        """Directive 4: Compile-time numerical consistency check.
        
        Extracts numeric tokens from rendered text and ensures all claims are grounded in
        the verified evidence graph from evaluation.json. Halts compilation if unbacked
        numbers are detected.
        """
        valid_numbers: set[float] = {
            0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 100.0,
            0.05, 0.01, 0.001,
            float(evaluation.total_runs),
            float(evaluation.successful_runs),
            float(evaluation.failed_runs),
            float(max(1, evaluation.total_runs - 1)),
        }
        for s in evaluation.seeds_evaluated:
            valid_numbers.add(float(s))
        if hypothesis:
            valid_numbers.add(round(float(hypothesis.success_threshold), 4))
        if spec and spec.run_config:
            for v in spec.run_config.values():
                if isinstance(v, (int, float)):
                    valid_numbers.add(round(float(v), 4))

        for agg in evaluation.metric_aggregates.values():
            valid_numbers.add(round(agg.mean, 4))
            valid_numbers.add(round(agg.std_dev, 4))
            valid_numbers.add(round(agg.std_err, 4))
            valid_numbers.add(round(agg.target_threshold, 4))
            if agg.p_value_estimate is not None:
                valid_numbers.add(round(agg.p_value_estimate, 4))
            for v in agg.sample_values:
                valid_numbers.add(round(v, 4))
            if agg.statistical_analysis:
                st = agg.statistical_analysis
                valid_numbers.add(round(st.variance, 4))
                valid_numbers.add(round(st.standard_deviation, 4))
                valid_numbers.add(round(st.standard_error, 4))
                valid_numbers.add(float(st.degrees_of_freedom))
                if st.test_statistic is not None:
                    valid_numbers.add(round(st.test_statistic, 4))
                if st.p_value is not None:
                    valid_numbers.add(round(st.p_value, 4))
                if st.confidence_interval:
                    valid_numbers.add(round(st.confidence_interval[0], 4))
                    valid_numbers.add(round(st.confidence_interval[1], 4))

        # Scan for decimal floating point numbers and percentages (e.g. 99.9%, 99.9, 0.15)
        # Avoid pure integers (section numbers 1, 2, citation [1], etc.)
        pattern = re.compile(r"(?<![a-zA-Z0-9_\\])(\d+\.\d+)(%|\\%)?|(?<![a-zA-Z0-9_\\])(\d+)(%|\\%)")
        for m in pattern.finditer(text):
            num_str = m.group(1) or m.group(3)
            is_pct = bool(m.group(2) or m.group(4))
            try:
                val = float(num_str)
            except ValueError:
                continue

            matched = False
            candidates = [val]
            if is_pct:
                candidates.append(val / 100.0)
            else:
                candidates.append(val * 100.0)

            for c in candidates:
                for vn in valid_numbers:
                    if math.isclose(c, vn, abs_tol=1e-4, rel_tol=1e-4):
                        matched = True
                        break
                if matched:
                    break

            if not matched:
                raise EpistemicHonestyViolation(
                    f"NumericalConsistencyError: Manuscript contains unbacked numeric claim '{m.group(0)}' "
                    f"(numeric value={val}) that does not exist in verified evidence graph."
                )

    @classmethod
    def sanitize_academic_prose(cls, text: str) -> str:
        """Purge known superficial AI clichés in generated prose."""
        cleaned = text
        for pattern in cls.AI_CLICHE_PATTERNS:
            cleaned = pattern.sub("examine", cleaned)
        return cleaned

    @staticmethod
    def _clean_bib_key(paper_id: str, author: str = "Author", year: Optional[int] = None) -> str:
        """Create a deterministic BibTeX citation key."""
        last_name = author.strip().split()[-1] if author and author.strip() else "Author"
        clean_author = re.sub(r"[^a-zA-Z]", "", last_name) or "Author"
        yr = str(year) if year else "2024"
        clean_id = re.sub(r"[^a-zA-Z0-9]", "", paper_id)[-6:]
        return f"{clean_author.lower()}{yr}_{clean_id}"

    def _generate_figures(
        self,
        evaluation: EvaluationReport,
        raw_data_dir: Optional[Union[Path, str]] = None,
        raise_if_missing_trace: bool = False,
    ) -> list[tuple[Path, Path]]:
        """Generate empirical visualization figures strictly from authentic raw execution traces."""
        from research_os.manuscript.visualizer import MissingTraceError

        generated: list[tuple[Path, Path]] = []
        if not evaluation.seed_runs:
            return generated

        # Check for real multi-step trajectory files under raw_data/
        candidate_dirs = []
        if raw_data_dir:
            candidate_dirs.append(Path(raw_data_dir))
        candidate_dirs.extend([
            self.output_dir.parent / "raw_data",
            Path("experiments/runs") / self.run_id / "raw_data",
            Path("experiments/runs") / self.run_id / "output" / "raw_data",
        ])

        traces: dict[int, list[float]] = {}
        target_m = evaluation.target_metric

        for rdir in candidate_dirs:
            if rdir.is_dir():
                for p in rdir.glob("*"):
                    if p.is_file() and p.suffix.lower() in (".csv", ".jsonl"):
                        try:
                            # Attempt reading multi-step log
                            rows: list[float] = []
                            if p.suffix.lower() == ".csv":
                                import csv
                                with p.open("r", encoding="utf-8", errors="replace") as f:
                                    reader = csv.DictReader(f)
                                    for r in reader:
                                        if target_m in r:
                                            try:
                                                rows.append(float(r[target_m]))
                                            except (ValueError, TypeError):
                                                pass
                            elif p.suffix.lower() == ".jsonl":
                                with p.open("r", encoding="utf-8", errors="replace") as f:
                                    for line in f:
                                        if line.strip():
                                            obj = json.loads(line)
                                            if target_m in obj:
                                                try:
                                                    rows.append(float(obj[target_m]))
                                                except (ValueError, TypeError):
                                                    pass
                            if len(rows) >= 2:
                                # Found multi-step trace
                                for s in evaluation.seed_runs:
                                    traces[s.seed] = rows
                                break
                        except Exception:
                            pass
                if traces:
                    break

        if traces:
            try:
                pdf_p, png_p = self.visualizer.plot_time_series_with_envelope(
                    traces_by_seed=traces,
                    x_label="Execution Steps (t)",
                    y_label=f"Observed {evaluation.target_metric}",
                    title=f"Multi-Seed Convergence ({evaluation.target_metric})",
                    filename_prefix="empirical_convergence",
                )
                generated.append((pdf_p, png_p))
            except Exception:
                pass
        else:
            if raise_if_missing_trace:
                raise MissingTraceError(
                    f"Real raw trajectory/time-series data for '{evaluation.target_metric}' does not exist under raw_data/ "
                    "across evaluation seeds. Refusing to synthesize fake trajectories."
                )

            # Evidence-Preserving Figure Policy:
            # If real raw multi-step trace data does not exist, generate only a bar/distribution chart
            # representing the verified scalar metric across seeds
            scalars_by_seed: dict[int, float] = {}
            for s in evaluation.seed_runs:
                val = s.metrics.get(evaluation.target_metric)
                if isinstance(val, (int, float)):
                    scalars_by_seed[s.seed] = float(val)

            if scalars_by_seed:
                try:
                    pdf_p, png_p = self.visualizer.plot_scalar_bar_chart(
                        scalar_values_by_seed=scalars_by_seed,
                        metric_name=evaluation.target_metric,
                        title=f"Verified Empirical {evaluation.target_metric} Across Seeds",
                        filename_prefix="verified_metric_distribution",
                    )
                    generated.append((pdf_p, png_p))
                except Exception:
                    pass

        return generated

    def compile(
        self,
        hypothesis: HypothesisProposal,
        spec: ExperimentSpec,
        evaluation: EvaluationReport,
        synthesis: Optional[CrossPaperSynthesis] = None,
        papers: Optional[list[PaperMetadata]] = None,
    ) -> ManuscriptBundle:
        """Compile a complete research paper to Markdown, LaTeX, and BibTeX."""
        papers_map: dict[str, PaperMetadata] = {}
        if papers:
            for p in papers:
                papers_map[p.paper_id] = p

        citation_keys: dict[str, str] = {}
        bib_entries: list[str] = []

        for pid, p in papers_map.items():
            author = p.authors[0] if p.authors else "Scholar"
            key = self._clean_bib_key(pid, author, p.year)
            citation_keys[pid] = key
            authors_str = " and ".join(p.authors) if p.authors else "Anonymous"
            venue_str = p.venue or "Preprint / Technical Report"
            year_val = p.year or 2024
            bib_entry = (
                f"@article{{{key},\n"
                f"  title = {{{p.title}}},\n"
                f"  author = {{{authors_str}}},\n"
                f"  journal = {{{venue_str}}},\n"
                f"  year = {{{year_val}}},\n"
                f"  url = {{{p.url or ''}}}\n"
                f"}}"
            )
            bib_entries.append(bib_entry)

        # Invariant: Purge hardcoded or placeholder fallback citations (e.g. researchos2025).
        # If no verified references exist in the ingested corpus, do NOT fabricate citations.

        figures = self._generate_figures(evaluation)
        fig_rel_paths = [str(f[1].relative_to(self.output_dir)).replace("\\", "/") for f in figures]

        exp_class = spec.experiment_class
        if exp_class == ExperimentClass.SIMULATION:
            title = f"Simulation Study of {hypothesis.title}: Operationalizing {hypothesis.proposed_mechanism}"
        elif exp_class == ExperimentClass.SYNTHETIC_BENCHMARK:
            title = f"Synthetic Benchmark Evaluation of {hypothesis.title}: Operationalizing {hypothesis.proposed_mechanism}"
        elif exp_class == ExperimentClass.REPRODUCTION:
            title = f"Reproduction Study of {hypothesis.title}: Operationalizing {hypothesis.proposed_mechanism}"
        else:
            title = f"Empirical Evaluation of {hypothesis.title}: Operationalizing {hypothesis.proposed_mechanism}"

        md_text = self._build_markdown(
            title=title,
            hypothesis=hypothesis,
            spec=spec,
            evaluation=evaluation,
            synthesis=synthesis,
            citation_keys=citation_keys,
            papers_map=papers_map,
            figure_paths=fig_rel_paths,
        )

        tex_text = self._build_latex(
            title=title,
            hypothesis=hypothesis,
            spec=spec,
            evaluation=evaluation,
            synthesis=synthesis,
            citation_keys=citation_keys,
            papers_map=papers_map,
            figures=figures,
        )

        # Directive 4: Resolve symbolic evidence claims and enforce compile-time numerical consistency
        md_text = self.resolve_evidence_claims(md_text, evaluation)
        tex_text = self.resolve_evidence_claims(tex_text, evaluation)

        self.verify_numerical_consistency(md_text, evaluation, hypothesis, spec)
        self.verify_numerical_consistency(tex_text, evaluation, hypothesis, spec)

        # Directive 3 & 4: Enforce Scientific Integrity & Epistemic Honesty Gate
        ScientificIntegrityLinter.assert_integrity(md_text, exp_class, evaluation)
        ScientificIntegrityLinter.assert_integrity(tex_text, exp_class, evaluation)

        md_path = self.output_dir / "paper.md"
        tex_path = self.output_dir / "paper.tex"
        bib_path = self.output_dir / "references.bib"

        md_path.write_text(md_text, encoding="utf-8")
        tex_path.write_text(tex_text, encoding="utf-8")
        bib_content = "\n\n".join(bib_entries) + "\n" if bib_entries else "% No verified references supplied\n"
        bib_path.write_text(bib_content, encoding="utf-8")

        word_count = len(md_text.split())

        return ManuscriptBundle(
            run_id=self.run_id,
            markdown_path=str(md_path),
            latex_path=str(tex_path),
            bibtex_path=str(bib_path),
            figure_paths=[str(f[1]) for f in figures],
            title=title,
            word_count=word_count,
        )

    def _build_markdown(
        self,
        title: str,
        hypothesis: HypothesisProposal,
        spec: ExperimentSpec,
        evaluation: EvaluationReport,
        synthesis: Optional[CrossPaperSynthesis],
        citation_keys: dict[str, str],
        papers_map: dict[str, PaperMetadata],
        figure_paths: list[str],
    ) -> str:
        """Construct academic paper in GitHub-flavored Markdown."""
        exp_class = spec.experiment_class
        study_type = (
            "simulation study"
            if exp_class == ExperimentClass.SIMULATION
            else "synthetic benchmark evaluation"
            if exp_class == ExperimentClass.SYNTHETIC_BENCHMARK
            else "reproduction study"
            if exp_class == ExperimentClass.REPRODUCTION
            else "empirical evaluation"
        )
        verdict_type = "computational verdict" if exp_class != ExperimentClass.EMPIRICAL else "empirical verdict"

        lines: list[str] = []
        lines.append(f"# {title}\n")
        lines.append("**Authors:** Research OS Autonomous Scientific Engine  ")
        lines.append(f"**Run ID:** `{self.run_id}` | **Verdict:** **{evaluation.verdict.value}**\n")
        lines.append("---\n")

        # Abstract
        lines.append("## Abstract\n")
        abstract_text = (
            f"We present an automated {study_type} investigating the hypothesis that "
            f"*{hypothesis.falsifiable_statement}*. Addressing documented scientific gaps in baseline "
            f"{hypothesis.baseline_method}, we formalize and test the integration of {hypothesis.proposed_mechanism}. "
            f"Under a multi-seed protocol ({len(spec.random_seeds)} stochastic seeds evaluated under "
            f"{spec.experiment_type.value} operationalization), the experimental data produced a {verdict_type} of "
            f"**{evaluation.verdict.value}** for target metric `{evaluation.target_metric}`. "
            f"{evaluation.summary_rationale} All execution telemetry, random seeds, and metric derivations are fully preserved "
            f"for deterministic verification."
        )
        abstract_text = ScientificIntegrityLinter.sanitize_epistemic_claims(abstract_text, exp_class)
        lines.append(self.sanitize_academic_prose(abstract_text) + "\n")

        # Introduction
        lines.append("## 1. Introduction\n")
        intro_prefix = (
            "Rigorous computational science requires systematically testing falsifiable hypotheses against explicit baselines. "
            if exp_class != ExperimentClass.EMPIRICAL
            else "Rigorous empirical science requires systematically testing falsifiable hypotheses against explicit baselines. "
        )
        intro_text = (
            f"{intro_prefix}In this work, we investigate: **\"{hypothesis.falsifiable_statement}\"**.\n\n"
            f"### Theoretical Foundation\n{hypothesis.theoretical_rationale}\n\n"
            f"### Baseline Comparison\n"
            f"- **Baseline Method:** {hypothesis.baseline_method}\n"
            f"- **Proposed Mechanism:** {hypothesis.proposed_mechanism}\n"
            f"- **Primary Target Metric:** `{hypothesis.target_metric}` (Expected direction: {hypothesis.expected_direction})\n"
            f"- **Success Threshold:** {hypothesis.success_threshold}\n"
        )
        intro_text = ScientificIntegrityLinter.sanitize_epistemic_claims(intro_text, exp_class)
        lines.append(self.sanitize_academic_prose(intro_text))

        # Related Work
        lines.append("## 2. Related Work & Grounded Synthesis\n")
        if synthesis and synthesis.identified_gaps:
            lines.append("Prior literature establishes foundational baselines and open challenges across the problem domain:\n")
            for gap in synthesis.identified_gaps:
                cites = [f"[@{citation_keys.get(pid, pid)}]" for pid in gap.evidence_paper_ids]
                lines.append(f"- **{gap.gap_id}**: {gap.description} {' '.join(cites)}")
                lines.append(f"  *Impact:* {gap.impact_potential}")
            lines.append("")
        elif hypothesis.inspired_by_seeds:
            lines.append("The current hypothesis borrows established architectural mechanisms with strict provenance:\n")
            for seed in hypothesis.inspired_by_seeds:
                lines.append(f"- **{seed.borrowed_aspect}** (Domain: {seed.domain}) as established in *{seed.paper_title}*.")
            lines.append("")
        else:
            lines.append("Prior work has established foundational baselines; the present study formulates an isolated comparison.\n")

        # Methodology
        lines.append("## 3. Methodology & Formal Specification\n")
        method_text = (
            f"The experimental design is operationalized as a `{spec.experiment_type.value}` protocol. "
            f"Execution is governed by deterministic entry point `{spec.entry_point}` with resource boundaries "
            f"requiring at least {spec.hardware_requirements.min_ram_gb} GB RAM.\n\n"
            f"### Independent & Dependent Variables\n"
            f"- **Independent Variable:** Random seeds {spec.random_seeds}, parameter configuration: `{spec.run_config}`\n"
            f"- **Dependent Variables / Expected Outputs:** {', '.join(spec.expected_outputs)}\n"
        )
        lines.append(self.sanitize_academic_prose(method_text))

        # Evaluation Section
        sec_name = "Empirical Evaluation" if exp_class == ExperimentClass.EMPIRICAL else "Experimental Evaluation"
        lines.append(f"## 4. {sec_name}\n")
        lines.append(f"The multi-seed evaluation executed {evaluation.total_runs} seed trials ({evaluation.successful_runs} successful, {evaluation.failed_runs} failed).\n")
        lines.append("| Metric Name | Mean ($M$) | Std Dev ($SD$) | Std Err ($SE$) | Target Condition | Passed | $p$-value |")
        lines.append("| :--- | :--- | :--- | :--- | :--- | :--- | :--- |")
        has_zero_var = False
        for m_name, agg in evaluation.metric_aggregates.items():
            if len(agg.sample_values) > 1 and agg.std_dev == 0.0:
                p_val = "N/A*"
                has_zero_var = True
            elif evaluation.total_runs < 2:
                p_val = "N/A"
            elif agg.p_value_estimate is not None:
                p_val = f"{agg.p_value_estimate:.4f}"
            else:
                p_val = "N/A"
            cond = f"{agg.operator} {agg.target_threshold}"
            lines.append(f"| `{m_name}` | {agg.mean:.4f} | {agg.std_dev:.4f} | {agg.std_err:.4f} | {cond} | {'Yes' if agg.passed else 'No'} | {p_val} |")
        lines.append("")
        if has_zero_var:
            lines.append(r"\* *Identical outputs observed across seeds ($SD = 0.0000$); null hypothesis significance testing uninformative.*" + "\n")

        if figure_paths:
            fig_caption = (
                "Multi-seed convergence envelope showing ensemble mean and empirical dispersion across stochastic runs."
                if exp_class == ExperimentClass.EMPIRICAL
                else "Multi-seed convergence envelope showing ensemble mean and dispersion across simulation runs."
            )
            lines.append(f"![Multi-Seed Convergence]({figure_paths[0]})\n")
            lines.append(f"*{fig_caption}*\n")

        lines.append("### Per-Seed Execution Trace\n")
        lines.append("| Seed | Run ID | Exit Code | Verification Status | Primary Metric Value |")
        lines.append("| :--- | :--- | :--- | :--- | :--- |")
        for s in evaluation.seed_runs:
            val = s.metrics.get(evaluation.target_metric, "N/A")
            val_str = f"{val:.4f}" if isinstance(val, (int, float)) else str(val)
            lines.append(f"| {s.seed} | `{s.run_id}` | {s.exit_code} | {s.verification_status} | {val_str} |")
        lines.append("")

        # Discussion, Limitations & Novelty Hedging (Rule 2)
        lines.append("## 5. Discussion, Limitations & Hedging\n")
        interp_header = "### Empirical Interpretation\n" if exp_class == ExperimentClass.EMPIRICAL else "### Computational Interpretation\n"
        hedging_note = (
            "claims of priority and generalizability are strictly hedged subject to broader peer scrutiny and wider real-world validation. "
            if exp_class == ExperimentClass.EMPIRICAL
            else "claims of priority and generalizability are strictly hedged subject to broader peer scrutiny and future empirical transfer. "
        )
        disc_text = (
            f"{interp_header}{evaluation.summary_rationale}\n\n"
            f"### Novelty Hedging & Scope Limits (Rule 2)\n"
            f"> **Epistemic Notice:** No close match was identified within the examined literature corpus; "
            f"{hedging_note}"
            f"The observed performance characteristics are demonstrated only within the evaluated parameter regime.\n\n"
            f"### Reproducibility Audit\n"
            f"- **Execution Engine:** Policy-controlled subprocess runner\n"
            f"- **Artifacts Directory:** `experiments/runs/{self.run_id}/`\n"
            f"- **Deterministic Seeds:** `{spec.random_seeds}`\n"
        )
        disc_text = ScientificIntegrityLinter.sanitize_epistemic_claims(disc_text, exp_class)
        lines.append(self.sanitize_academic_prose(disc_text))

        # References
        lines.append("## References\n")
        if citation_keys:
            for pid, key in citation_keys.items():
                p = papers_map.get(pid)
                if p:
                    authors_str = ", ".join(p.authors[:3]) + (" et al." if len(p.authors) > 3 else "")
                    lines.append(f"- **[@{key}]** {authors_str} ({p.year or 'n.d.'}). *{p.title}*. {p.venue or 'Preprint'}.")
                else:
                    lines.append(f"- **[@{key}]** Reference ({key}).")
        else:
            lines.append("No verified references supplied.\n")

        return "\n".join(lines) + "\n"

    def _build_latex(
        self,
        title: str,
        hypothesis: HypothesisProposal,
        spec: ExperimentSpec,
        evaluation: EvaluationReport,
        synthesis: Optional[CrossPaperSynthesis],
        citation_keys: dict[str, str],
        papers_map: dict[str, PaperMetadata],
        figures: list[tuple[Path, Path]],
    ) -> str:
        """Construct publication-ready IEEEtran LaTeX article using structured LaTeX AST."""
        exp_class = spec.experiment_class
        doc = LatexDocument()

        doc.add(LatexCommand("title", title))
        doc.add(LatexCommand("author", "Research OS Autonomous Scientific System"))
        doc.add(LatexRaw("\\maketitle\n"))

        # Abstract
        study_type = (
            "simulation study"
            if exp_class == ExperimentClass.SIMULATION
            else "synthetic benchmark evaluation"
            if exp_class == ExperimentClass.SYNTHETIC_BENCHMARK
            else "reproduction study"
            if exp_class == ExperimentClass.REPRODUCTION
            else "empirical evaluation"
        )
        verdict_type = "computational verdict" if exp_class != ExperimentClass.EMPIRICAL else "empirical verdict"

        abs_text = (
            f"We present an automated {study_type} investigating the hypothesis that "
            f"{hypothesis.falsifiable_statement}. Addressing documented scientific gaps in baseline "
            f"{hypothesis.baseline_method}, we operationalize and test {hypothesis.proposed_mechanism}. "
            f"Under a multi-seed protocol ({len(spec.random_seeds)} stochastic seeds under "
            f"{spec.experiment_type.value} operationalization), results yield a {verdict_type} of "
            f"\\textbf{{{evaluation.verdict.value}}} for target metric {escape_latex(evaluation.target_metric)}. "
            f"{evaluation.summary_rationale}"
        )
        abs_text = ScientificIntegrityLinter.sanitize_epistemic_claims(abs_text, exp_class)
        abs_text = self.sanitize_academic_prose(abs_text)

        abs_env = LatexEnvironment("abstract")
        abs_env.add(LatexText(abs_text, raw=True))
        doc.add(abs_env)

        # Keywords
        kw_env = LatexEnvironment("IEEEkeywords")
        kw_text = (
            "Autonomous Discovery, Multi-Seed Evaluation, In-Silico Verification, Statistical Provenance"
            if exp_class != ExperimentClass.EMPIRICAL
            else "Autonomous Discovery, Multi-Seed Evaluation, Empirical Verification, Statistical Provenance"
        )
        kw_env.add(LatexText(kw_text))
        doc.add(kw_env)

        # Section 1: Introduction
        doc.add(LatexCommand("section", "Introduction"))
        intro_prefix = (
            "Rigorous computational science requires testing falsifiable hypotheses against verified baselines. "
            if exp_class != ExperimentClass.EMPIRICAL
            else "Rigorous empirical science requires testing falsifiable hypotheses against verified baselines. "
        )
        intro_body = (
            f"{intro_prefix}Here we evaluate the formal prediction: \\textit{{{escape_latex(hypothesis.falsifiable_statement)}}}.\n"
        )
        intro_body = ScientificIntegrityLinter.sanitize_epistemic_claims(intro_body, exp_class)
        doc.add(LatexText(self.sanitize_academic_prose(intro_body), raw=True))

        doc.add(LatexCommand("subsection", "Baseline vs. Proposed Mechanism"))
        doc.add(LatexText(f"\\textbf{{Baseline Method:}} {escape_latex(hypothesis.baseline_method)}\\\\\n", raw=True))
        doc.add(LatexText(f"\\textbf{{Proposed Mechanism:}} {escape_latex(hypothesis.proposed_mechanism)}\\\\\n", raw=True))
        doc.add(LatexText(f"\\textbf{{Success Threshold:}} {escape_latex(str(hypothesis.success_threshold))} ({escape_latex(hypothesis.expected_direction)})\n", raw=True))

        # Section 2: Related Work
        doc.add(LatexCommand("section", "Related Work"))
        if synthesis and synthesis.identified_gaps:
            doc.add(LatexText("The investigated problems relate to critical open challenges in the literature:"))
            item_env = LatexEnvironment("itemize")
            for gap in synthesis.identified_gaps:
                cites = [f"\\cite{{{citation_keys.get(pid, 'ref')}}}" for pid in gap.evidence_paper_ids]
                cites_str = " ".join(cites)
                item_env.add(LatexText(f"\\item \\textbf{{{escape_latex(gap.gap_id)}}}: {escape_latex(gap.description)} {cites_str}", raw=True))
            doc.add(item_env)
        else:
            doc.add(LatexText("Related literature establishes the foundational baselines against which this investigation is contrasted."))

        # Section 3: Methodology
        doc.add(LatexCommand("section", "Methodology \\& Execution Protocol", escape_arg=False))
        method_str = (
            f"Experiments were executed under protocol \\texttt{{{escape_latex(spec.experiment_type.value)}}}. "
            f"The environment adheres to deterministic seed sweeps \\{{{', '.join(str(s) for s in spec.random_seeds)}\\}} "
            f"with system entry point \\texttt{{{escape_latex(spec.entry_point)}}}."
        )
        doc.add(LatexText(method_str, raw=True))

        # Section 4: Evaluation
        sec4_title = "Empirical Evaluation" if exp_class == ExperimentClass.EMPIRICAL else "Experimental Evaluation"
        doc.add(LatexCommand("section", sec4_title))
        eval_intro = (
            f"The multi-seed evaluation executed {evaluation.total_runs} seed runs "
            f"({evaluation.successful_runs} passed, {evaluation.failed_runs} failed). "
            f"The aggregated statistical metrics are summarized in Table~\\ref{{tab:metrics}}."
        )
        doc.add(LatexText(eval_intro, raw=True))

        # Statistical Table via Typed AST Node (Directive 4)
        doc.add(LatexMetricTable(evidence_table_ref=evaluation))

        # Figures via Typed AST Node (Directive 4)
        if figures:
            fig_path = figures[0][1]
            fig_caption = (
                "Multi-seed convergence envelope showing ensemble mean and dispersion across stochastic runs."
                if exp_class != ExperimentClass.EMPIRICAL
                else "Empirical convergence across stochastic seeds showing ensemble mean and dispersion."
            )
            doc.add(
                LatexVerifiedFigure(
                    figure_path=fig_path,
                    manuscript_dir=self.output_dir,
                    caption=fig_caption,
                    label="fig:convergence",
                )
            )

        # Section 5: Discussion & Novelty Hedging
        doc.add(LatexCommand("section", "Discussion \\& Novelty Hedging", escape_arg=False))
        rationale_cleaned = self.sanitize_academic_prose(
            ScientificIntegrityLinter.sanitize_epistemic_claims(evaluation.summary_rationale, exp_class)
        )
        doc.add(LatexText(f"\\textbf{{Scientific Rationale:}} {escape_latex(rationale_cleaned)}\\\\\n", raw=True))

        hedging_note = (
            "\\textbf{Novelty Hedging Notice (Rule 2):} No close match was identified within the examined literature corpus; "
            "claims of priority and generalizability are strictly hedged subject to broader peer review and future empirical evaluation.\n"
        )
        doc.add(LatexText(hedging_note, raw=True))

        # Bibliography
        if citation_keys:
            doc.add(LatexCommand("bibliographystyle", "IEEEtran", escape_arg=False))
            doc.add(LatexCommand("bibliography", "references", escape_arg=False))
        else:
            doc.add(LatexText("% No verified references supplied\n\\section*{References}\nNo verified references supplied.\n", raw=True))

        return doc.render()
